
package com.soa.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.soa.entity.ParkingPayment;

public interface PaymentRepository
        extends JpaRepository<ParkingPayment, Long> {
}
