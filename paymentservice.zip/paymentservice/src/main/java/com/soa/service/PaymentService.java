
package com.soa.service;

import java.util.List;
import java.util.Map;

import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.client.ResourceAccessException;
import org.springframework.web.client.RestClientResponseException;
import org.springframework.web.server.ResponseStatusException;

import com.soa.client.BookingServiceClient;
import com.soa.entity.ParkingPayment;
import com.soa.repository.PaymentRepository;

@Service
public class PaymentService {

    private final PaymentRepository paymentRepository;
    private final BookingServiceClient bookingServiceClient;

    public PaymentService(
            PaymentRepository paymentRepository,
            BookingServiceClient bookingServiceClient) {
        this.paymentRepository = paymentRepository;
        this.bookingServiceClient = bookingServiceClient;
    }

    public ParkingPayment createPayment(ParkingPayment payment) {

        if (payment.getBookingId() == null) {
            throw new ResponseStatusException(
                    HttpStatus.BAD_REQUEST, "Booking ID is required");
        }

        if (payment.getAmount() <= 0
                || !Double.isFinite(payment.getAmount())) {
            throw new ResponseStatusException(
                    HttpStatus.BAD_REQUEST,
                    "Amount must be a valid positive number");
        }

        if (payment.getPaymentMethod() == null
                || payment.getPaymentMethod().isBlank()) {
            throw new ResponseStatusException(
                    HttpStatus.BAD_REQUEST,
                    "Payment method is required");
        }

        Map<String, Object> booking;

        try {
            booking = bookingServiceClient.getBooking(
                    payment.getBookingId());

        } catch (RestClientResponseException ex) {
            if (ex.getStatusCode().value() == 404) {
                throw new ResponseStatusException(
                        HttpStatus.NOT_FOUND, "Booking does not exist");
            }

            throw new ResponseStatusException(
                    HttpStatus.BAD_GATEWAY,
                    "Booking Service returned an error");

        } catch (ResourceAccessException ex) {
            throw new ResponseStatusException(
                    HttpStatus.SERVICE_UNAVAILABLE,
                    "Booking Service is unavailable");
        }

        String bookingStatus = (String) booking.get("status");

        if (!"BOOKED".equals(bookingStatus)) {
            throw new ResponseStatusException(
                    HttpStatus.CONFLICT,
                    "Payment requires an active booking");
        }

        payment.setId(null);
        payment.setStatus("SUCCESS");
        payment.setPaymentTime(null);

        return paymentRepository.save(payment);
    }

    public List<ParkingPayment> getAllPayments() {
        return paymentRepository.findAll();
    }

    public ParkingPayment getPaymentById(Long id) {
        return paymentRepository.findById(id)
                .orElseThrow(() -> new ResponseStatusException(
                        HttpStatus.NOT_FOUND,
                        "Payment not found with ID: " + id));
    }

    public List<ParkingPayment> getPaymentsByBookingId(Long bookingId) {
        return paymentRepository.findAll().stream()
                .filter(payment ->
                        bookingId.equals(payment.getBookingId()))
                .toList();
    }
}
