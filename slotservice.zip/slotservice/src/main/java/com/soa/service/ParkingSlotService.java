
package com.soa.service;

import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;

import com.soa.entity.ParkingSlot;
import com.soa.repository.ParkingSlotRepository;

@Service
public class ParkingSlotService {

    private final ParkingSlotRepository parkingSlotRepository;

    public ParkingSlotService(ParkingSlotRepository parkingSlotRepository) {
        this.parkingSlotRepository = parkingSlotRepository;
    }

    // Get all parking slots
    public List<ParkingSlot> getAllSlots() {
        return parkingSlotRepository.findAll();
    }

    // Get a slot by ID
    public ParkingSlot getSlotById(Long id) {
        return parkingSlotRepository.findById(id)
                .orElseThrow(() -> new ResponseStatusException(
                        HttpStatus.NOT_FOUND, "Parking slot not found with ID: " + id));
    }

    // Create a new parking slot
    public ParkingSlot createSlot(ParkingSlot slot) {
        return parkingSlotRepository.save(slot);
    }

    // Update an existing parking slot
    public ParkingSlot updateSlot(Long id, ParkingSlot updatedSlot) {
        ParkingSlot existingSlot = getSlotById(id);

        existingSlot.setSlotNumber(updatedSlot.getSlotNumber());
        existingSlot.setVehicleType(updatedSlot.getVehicleType());
        existingSlot.setAvailable(updatedSlot.isAvailable());

        return parkingSlotRepository.save(existingSlot);
    }

    // Delete a parking slot
    public void deleteSlot(Long id) {
        ParkingSlot existingSlot = getSlotById(id);
        parkingSlotRepository.delete(existingSlot);
    }

    // Change availability of a parking slot
    public ParkingSlot updateAvailability(Long id, boolean available) {
        ParkingSlot slot = getSlotById(id);
        slot.setAvailable(available);
        return parkingSlotRepository.save(slot);
    }
}
