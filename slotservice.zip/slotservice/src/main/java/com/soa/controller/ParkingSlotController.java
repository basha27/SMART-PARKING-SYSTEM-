
package com.soa.controller;

import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.soa.entity.ParkingSlot;
import com.soa.service.ParkingSlotService;

@RestController
@RequestMapping("/api/slots")
public class ParkingSlotController {

    private final ParkingSlotService parkingSlotService;

    public ParkingSlotController(ParkingSlotService parkingSlotService) {
        this.parkingSlotService = parkingSlotService;
    }

    // GET: Retrieve all slots
    @GetMapping
    public ResponseEntity<List<ParkingSlot>> getAllSlots() {
        return ResponseEntity.ok(parkingSlotService.getAllSlots());
    }

    // GET: Retrieve one slot by ID
    @GetMapping("/{id}")
    public ResponseEntity<ParkingSlot> getSlotById(@PathVariable Long id) {
        return ResponseEntity.ok(parkingSlotService.getSlotById(id));
    }

    // POST: Create a new slot
    @PostMapping
    public ResponseEntity<ParkingSlot> createSlot(@RequestBody ParkingSlot slot) {
        ParkingSlot savedSlot = parkingSlotService.createSlot(slot);
        return ResponseEntity.status(HttpStatus.CREATED).body(savedSlot);
    }

    // PUT: Update a slot
    @PutMapping("/{id}")
    public ResponseEntity<ParkingSlot> updateSlot(
            @PathVariable Long id,
            @RequestBody ParkingSlot slot) {
        return ResponseEntity.ok(parkingSlotService.updateSlot(id, slot));
    }

    // PATCH: Change slot availability
    @PatchMapping("/{id}/availability")
    public ResponseEntity<ParkingSlot> updateAvailability(
            @PathVariable Long id,
            @RequestParam boolean available) {
        return ResponseEntity.ok(
                parkingSlotService.updateAvailability(id, available));
    }

    // DELETE: Delete a slot
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteSlot(@PathVariable Long id) {
        parkingSlotService.deleteSlot(id);
        return ResponseEntity.noContent().build();
    }
}
