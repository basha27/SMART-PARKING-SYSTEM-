
package com.soa.client;

import java.util.Map;

import org.springframework.stereotype.Component;
import org.springframework.web.client.RestClient;

@Component
public class BookingServiceClient {

    private final RestClient restClient;

    public BookingServiceClient(RestClient.Builder builder) {
        this.restClient = builder
                .baseUrl("http://localhost:8082")
                .build();
    }

    public Map<String, Object> getBooking(Long bookingId) {
        return restClient.get()
                .uri("/api/bookings/{id}", bookingId)
                .retrieve()
                .body(Map.class);
    }
}
