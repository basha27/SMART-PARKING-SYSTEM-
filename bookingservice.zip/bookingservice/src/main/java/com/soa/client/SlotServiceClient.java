
package com.soa.client;

import java.util.Map;

import org.springframework.stereotype.Component;
import org.springframework.web.client.RestClient;

@Component
public class SlotServiceClient {

    private final RestClient restClient;

    public SlotServiceClient(
            @org.springframework.beans.factory.annotation.Qualifier(
                    "loadBalancedRestClientBuilder")
            RestClient.Builder builder) {
        this.restClient = builder
                .baseUrl("http://slotservice")
                .build();
    }

    public Map<String, Object> getSlot(Long slotId) {
        return restClient.get()
                .uri("/api/slots/{id}", slotId)
                .retrieve()
                .body(Map.class);
    }

    public Map<String, Object> updateAvailability(
            Long slotId, boolean available) {

        return restClient.patch()
                .uri("/api/slots/{id}/availability?available={available}",
                        slotId, available)
                .retrieve()
                .body(Map.class);
    }
}
