
package com.soa.service;

import java.util.List;
import java.util.Map;

import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestClientResponseException;
import org.springframework.web.server.ResponseStatusException;

import com.soa.client.SlotServiceClient;
import com.soa.entity.ParkingBooking;
import com.soa.repository.BookingRepository;

@Service
public class BookingService {

    private final BookingRepository bookingRepository;
    private final SlotServiceClient slotServiceClient;

    public BookingService(
            BookingRepository bookingRepository,
            SlotServiceClient slotServiceClient) {
        this.bookingRepository = bookingRepository;
        this.slotServiceClient = slotServiceClient;
    }

    public ParkingBooking createBooking(ParkingBooking booking) {

        if (booking.getSlotId() == null) {
            throw new ResponseStatusException(
                    HttpStatus.BAD_REQUEST, "Slot ID is required");
        }

        Map<String, Object> slot;

        try {
            slot = slotServiceClient.getSlot(booking.getSlotId());
        } catch (RestClientResponseException ex) {
            if (ex.getStatusCode().value() == 404) {
                throw new ResponseStatusException(
                        HttpStatus.NOT_FOUND, "Parking slot does not exist");
            }
            throw new ResponseStatusException(
                    HttpStatus.BAD_GATEWAY, "Slot Service request failed");
        } catch (Exception ex) {
            throw new ResponseStatusException(
                    HttpStatus.SERVICE_UNAVAILABLE, "Slot Service is unavailable");
        }

        if (!Boolean.TRUE.equals(slot.get("available"))) {
            throw new ResponseStatusException(
                    HttpStatus.CONFLICT, "Parking slot is not available");
        }

        booking.setId(null);
        booking.setStatus("BOOKED");
        booking.setBookingTime(null);

        ParkingBooking savedBooking = bookingRepository.save(booking);

        try {
            slotServiceClient.updateAvailability(booking.getSlotId(), false);
        } catch (Exception ex) {
            bookingRepository.delete(savedBooking);
            throw new ResponseStatusException(
                    HttpStatus.BAD_GATEWAY,
                    "Could not reserve the slot; booking was not saved");
        }

        return savedBooking;
    }

    public List<ParkingBooking> getAllBookings() {
        return bookingRepository.findAll();
    }

    public ParkingBooking getBookingById(Long id) {
        return bookingRepository.findById(id)
                .orElseThrow(() -> new ResponseStatusException(
                        HttpStatus.NOT_FOUND,
                        "Booking not found with ID: " + id));
    }

    public ParkingBooking cancelBooking(Long id) {
        ParkingBooking booking = getBookingById(id);

        if ("CANCELLED".equals(booking.getStatus())) {
            throw new ResponseStatusException(
                    HttpStatus.CONFLICT, "Booking is already cancelled");
        }

        slotServiceClient.updateAvailability(booking.getSlotId(), true);

        booking.setStatus("CANCELLED");
        return bookingRepository.save(booking);
    }
}
