package com.soa.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.soa.entity.ParkingBooking;

public interface BookingRepository
        extends JpaRepository<ParkingBooking, Long> {
}